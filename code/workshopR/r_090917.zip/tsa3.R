library(zoo)
library(xts)
library(tseries)

# Hent historiske finansielle data fra Yahoo Finance
ibm <- get.hist.quote(instrument = "ibm", quote = "Close", start = "1970-01-01", end = "1979-12-31")
# Se de 6 �ldste observationer
head(ibm)
# Se de 6 nyeste observationer
tail(ibm)
# Se de 20 nyeste observationer
tail(ibm, 20)
# Funktionerne first og last fra xts-pakken bruger kalenderperioder frem for antal observationer
# Vi kan bruge first og last til at udv�lge data efter antal dage, uger, m�neder eller �r
first(as.xts(ibm), "3 weeks")
last(as.xts(ibm), "month")
# Bem�rk at en uge er defineret af kalenderen, ikke blot vilk�rlige syv p� hinanden f�lgende dage
# Brug eventuelt den indbyggede hj�lpefunktion, hvis du vil vide mere om funktionerne first og last
help(first.xts)
help(last.xts)