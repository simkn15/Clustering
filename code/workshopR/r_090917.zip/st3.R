library(isdals)

# Antag nu, at vi har en stikpr�ve fra hver af to populationer og �nsker at vide om de kunne have samme middelv�rdi

# Vi indl�ser datas�ttet lucerne
data(lucerne)

# Udf�r en t-test ved at kalde funktionen t.test
# Som standard antager t.test, at dine data ikke er parrede - hvis observationerne er parrede skriver vi paired = TRUE
# I begge tilf�lde vil t.test beregne en p-v�rdi - og if�lge konventionen:
# - Hvis p < 0,05 er middelv�rdierne sandsynligvis forskellige
# - Hvis p > 0,05 er der ingen s�dan evidens
# Hvis en af stikpr�vernes st�rrelser er lille (dvs. mindre end 20 datapunkter) kr�ves normalfordeling af populationerne
# Hvis de to populationer har samme varians, s� skriv var.equal = TRUE for at opn� en mindre konservativ test
t.test(lucerne$seeds.exp, lucerne$seeds.bent, paired = TRUE)
