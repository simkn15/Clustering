# Vi bygger nu videre p� eksemplet fra forrige fil
with(iris, plot(Petal.Length, Petal.Width, xlab = "Kronbladl�ngde", ylab = "Kronbladbredde", pch = as.integer(Species)))
# Vi tilf�jer en signaturforklaring
legend("topleft", horiz = TRUE, legend = c("setosa", "versicolor", "virginica"), pch = 1:3, bty = "n")

# Vi kan ogs� undg� at skrive arternes navne i R-koden, men i stedet bruge art-faktoren f
f <- factor(iris$Species)
with(iris, plot(Petal.Length, Petal.Width, xlab = "Kronbladl�ngde", ylab = "Kronbladbredde", pch = as.integer(f)))
legend("topleft", horiz = TRUE, legend = as.character(levels(f)), pch = 1:length(levels(f)), bty = "n")
# Dette har f�lgende fordele:
# 1. Man undg�r at glemme et artsnavn eller skrive et artsnavn forkert
# 2. Hvis nogen tilf�jer endnu en art, s� tilpasser koden sig automatisk