# Forst�else af "genbrugsreglen" - hvordan h�ndterer R vektorer af forskellig l�ngde?

# N�r vi udf�rer vektoraritmetik, s� udf�rer R operationerne element-efter-element
# Det fungerer fint, n�r begge vektorer har samme l�ngde: R parrer elementerne i vektorerne og anvender operationen p� disse par

# N�r vektorerne har forskellig l�ngde, s� bruger R den s�kaldte "genbrugsregel":
# Den behandler vektorelementerne i par, startende med det f�rste element i begge vektorer
# P� et bestemt tidspunkt bliver elementerne i den korteste vektor opbrugt, men den l�ngste har stadig ubehandlede elementer
# R g�r tilbage til begyndelsen af den korteste vektor og "genbruger" dens elementer, men forts�tter med den l�ngste
# Den genbruger elementerne i den korteste vektor s� ofte som det er n�dvendigt indtil operationen er f�rdig

# Vektoren 1:6 er l�ngere end vektoren 1:3, men R genbruger elementerne i 1:3 (se nedenst�ende "illustration")
(1:6) + (1:3)

#   1:6  1:3  (1:6)+(1:3)
#  -----------------------
#   1    1    2
#   2    2    4
#   3    3    6
#   4    1    5
#   5    2    7
#   6    3    9

# Ogs� funktioner bruger denne regel
# Funktionen cbind kan lave s�jlevektorer ud fra eksempelvis 1:6 og 1:3 (disse vil selvsagt ikke blive lige h�je)
cbind(1:6)
cbind(1:3)
cbind(1:6, 1:3)

# Hvis den l�ngste vektors l�ngde ikke er et multiplum af den korteste vektors l�ngde giver R en advarsel
(1:6) + (1:5)

# N�r man forst�r denne regel vil man indse, at operationer mellem en vektor og en skalar er anvendelser af den
# Her genbruges 10 gentagne gange ind til vektoradditionen er udf�rt
(1:6) + 10
