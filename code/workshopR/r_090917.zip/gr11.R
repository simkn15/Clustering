# Her plottes et diagram med tre s�jler, som farves henholdsvis r�d, hvid og bl� (her bruges eksplicitte farver)
barplot(c(3, 5, 4), col = c("red", "white", "blue"))

# Vi arbejder videre med det indbyggede airquality-datas�t
attach(airquality)
# I den forrige fil beregnede vi gruppernes middelv�rdier ved hj�lp af mean-funktionen
heights <- tapply(Temp, Month, mean)

# En typisk effekt er, at skravere s�jlerne efter deres rang (lavere s�jler er lysere, h�jere s�jler er m�rkere)

# For at skravere s�jlediagrammet konverterer vi s�jlernes rang til relativ h�jde, udtrykt som en v�rdi mellem 0 og 1
rel.hts <- rank(heights) / length(heights)
# Vi kan bruge gray-funktionen til at generere en vektor af gr�toner (eller rainbow-funktionen for en vektor af farver)
# Som argument tager denne funktion en vektor af numeriske v�rdier mellem 0 og 1 og returnerer en gr�tone for hvert element:
# 0.0 = kulsort, 1.0 = kridhvid
# Bem�rk at vi her inverterer de relative h�jder, s� h�jere s�jler er m�rke, ikke lyse!
grays <- gray(1 - rel.hts)
# Vi fremstiller et skraveret s�jlediagram
barplot(heights, col = grays)
# Igen kan vi pynte lidt p� diagrammet
rel.hts <- (heights - min(heights)) / (max(heights) - min(heights))
grays <- gray(1 - rel.hts)
barplot(heights,
        col = grays,
        ylim = c(50, 90), xpd = FALSE,
        main = "Middeltemperatur per m�ned",
        names.arg = c("Maj", "Jun", "Jul", "Aug", "Sep"),
        ylab = "Temperatur (grader Fahrenheit)")