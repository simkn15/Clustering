# Antag nu, at vi �nsker at generere en tilf�ldig r�kke af simulerede m�ntkast eller Bernoulli-fors�g

# Vi kan bruge funktionen sample med tilbagel�gning ved at skrive replace = TRUE

# Her genereres en r�kke af 10 simulerede m�ntkast (P = plat, K = krone)
sample(c("P", "K"), 10, replace = TRUE)
# Her genereres en r�kke af 20 Bernoulli-fors�g - tilf�ldige succeser eller fiaskoer (TRUE = succes, FALSE = fiasko)
sample(c(TRUE, FALSE), 20, replace = TRUE)
# Som standard vil sample v�lge et uniformt tilf�ldigt element, s� TRUE og FALSE har hver sandsynlighed 0,5
# Med et Bernoulli-fors�g er successandsynligheden p ikke n�dvendigvis 0,5
# Her har TRUE sandsynlighed 0,8 og FALSE sandsynlighed 0,2
sample(c(TRUE, FALSE), 20, replace = TRUE, prob = c(0.8, 0.2))
# For det s�rlige tilf�lde med bin�re v�rdier kan vi bruge rbinom, tilf�ldighedsgeneratoren for binomiale variate
rbinom(10, 1, 0.8)
