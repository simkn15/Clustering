library(zoo)
library(tseries)

# Hent historiske finansielle data fra Yahoo Finance
ibm <- get.hist.quote(instrument = "ibm", quote = "Close", start = "1970-01-01", end = "1979-12-31")
# Forbrugerprisindeksdata (CPI-data) indl�ses
cpi <- read.zoo("CPIAUCNS.csv", header = TRUE, sep = ",", format = "%Y-%m-%d")
# Bem�rk at de to tidsr�kker har forskellige tidsstempler, da den ene er daglige data og den anden er m�nedlige data
# og CPI-dataene er tidsstemplede for den f�rste dag i hver m�ned, selv hvis denne dag er en helligdag eller weekend
merge(ibm, cpi)
# Funktionen merge finder som standard foreningsm�ngden af alle datoer
# Outputtet indeholder alle datoer fra begge input og manglende observationer udfyldes med NA-v�rdier
# Disse NA-v�rdier kan erstattes med den nyeste observation ved at bruge na.locf-funktionen
na.locf(merge(ibm, cpi))
# NA'erne er erstattet og funktionen eliminerede den f�rste observation, da der ingen IBM-aktiepris var for denne dag
# Vi kan f� f�llesm�ngden af alle datoerne ved at s�tte all = FALSE
merge(ibm, cpi, all = FALSE)
# Outputtet er begr�nset til observationerne, som er f�lles for begge filer

# Bem�rk at f�llesm�ngden begynder 1. april, ikke 1. januar (da 1/1, 1/2 og 1/3 alle er helligdage eller weekender)
# Der er ingen IBM-aktiepris for disse datoer og dermed ingen f�llesm�ngde med CPI-data! Dette h�ndterer vi om lidt!

# locf st�r for "last observation carried forward"