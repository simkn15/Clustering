# Antag nu, at vores output indeholder for mange cifre eller for f� cifre - og vi gerne vil printe flere eller f�rre

# R formaterer normalt output med decimaltal til at have 7 cifre
pi
100 * pi
# Dette fungerer for det meste fint, men det kan v�re irriterende, n�r man har mange tal og begr�nset plads
# Det kan v�re misvisende, hvis der kun er f� betydende cifre i dine tal og R fortsat printer 7
# Funktionen print lader dig variere antallet af printede cifre med digits-parameteret
print(pi, digits = 4)
print(100 * pi, digits = 4)
# Bem�rk at print formaterer hele vektorer ad gangen
pnorm(-3:3)
print(pnorm(-3:3), digits = 3)
# Bem�rk at print formaterer vektorelementer konsistent:
# Den finder antallet af cifre, som er n�dvendige for at formatere det mindste tal
# Dern�st formaterer den alle tal til at have samme bredde (ikke n�dvendigvis samme antal cifre)
# Dette er meget brugbart, n�r man skal formatere en hel tabel
q <- seq(from = 0, to = 3, by = 0.5)
tbl <- data.frame(Quant = q, Lower = pnorm(-q), Upper = pnorm(q))
# Uformateret print
tbl
# Formateret print: f�rre cifre
print(tbl, digits = 2)
# Du kan ogs� �ndre formatet af ALT output ved brug af options-funktionen
pi
options(digits = 15)
pi