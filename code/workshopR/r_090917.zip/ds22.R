# Antag nu, at vi �nsker at udv�lge s�jler fra en dataramme efter deres navn

# For at udv�lge en enkelt s�jle, brug et af disse udtryk:
# dfrm[["navn"]] - returnerer s�jlen kaldet navn
# dfrm$navn - samme som forrige, bare en alternativ syntaks

# For at udv�lge en eller flere s�jler og pakke dem ind i en dataramme, brug disse udtryk:
# dfrm["navn"] - udv�lger en s�jle og pakker den ind i en dataramme
# dfrm[c("navn_1", "navn_2", ..., "navn_k")] - udv�lger flere s�jler og pakker dem ind i en dataramme
# Man kan ogs� bruge matrixlignende indeksering til at udv�lge en eller flere s�jler:
# dfrm[, "navn"]
# dfrm[, c("navn_1", "navn_2", ..., "navn_k")]

# Samme udfordring som i forrige fil med returtyperne ved brug af matrixlignende indeksering!

# Pr�v selv at udv�lge s�jler fra en dataramme efter deres navne!
