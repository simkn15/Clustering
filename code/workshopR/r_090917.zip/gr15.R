library(MASS)

# Antag nu, at vores datas�t indeholder en numerisk variabel og en faktor (kategorisk variabel)
# Vi vil gerne fremstille flere boksplot af den numeriske variabel, opdelt efter faktorniveauer

# UScereal-datas�ttet indeholder mange variable om morgensmadsprodukter

# En variabel er sukkerm�ngde per portion og en anden er hyldeposition (hvor man t�ller fra gulvet)
# Leverand�rer af morgenmadsprodukter kan forhandle hyldeposition med henblik p� at �ge salgspotentialet
# Hvor mon de placerer morgenmadsprodukter med h�jt sukkerindhold?
# Dette kan vi unders�ge ved at fremstille et boksplot per hylde!
boxplot(sugars ~ shelf, data = UScereal)
# Vi tilf�jer etiketter p� akserne, s� det resulterende boksplot bliver lettere at fortolke
boxplot(sugars ~ shelf, data = UScereal,
        main = "Sukkerindhold efter hylde",
        xlab = "Hylde", ylab = "Sukker (gram per portion)")

# Boksplottene viser, at hylde 2 har flest sukkerholdige morgenmadsprodukter
# M�ske denne hylde er i �jenh�jde for sm� b�rn, som kan p�virke for�ldrenes valg?