# Antag nu, at vi har en stikpr�ve af v�rdier fra en population best�ende af succeser og fiaskoer
# Baseret p� stikpr�vedata vil vi gerne konstruere et konfidensinterval for populationens succesdel

# Antag at et nyhedsbrev indeholder et afsnit, der foregiver at identificere aktier, som med stor sandsynlighed vil stige
# Der meldes eksempelvis, at en bestemt aktie fulgte et m�nster - og at den steg 6 ud af 9 gange dette m�nster forekom
# Forfatterne konkluderer, at sandsynligheden for at aktien stiger igen derfor er 6/9 eller 66,7%

# Ved brug af prop.test kan vi opn� et konfidensinteral for den sande proportion af gangene aktien stiger efter m�nsteret
# Her er antallet af observationer n = 9 og antallet af succeser er x = 6
# Outputtet indeholder et 95% konfidensinterval: (0,309; 0,910)
prop.test(6, 9)

# Det er m�ske ikke s� klogt at sige, at sandsynligheden for en stigning er 66,7%
