library(MASS)

# Antag nu, at vi �nsker en lettere m�de til at udv�lge r�kker og s�jler fra en dataramme eller en matrix

# Indeksering kan v�re besv�rlig at bruge i visse tilf�lde
# Funktionen subset er en mere bekvem og l�sbar m�de at udv�lge r�kker og s�jler

# Find modelnavnet for biler, der kan overstige 30 miles per gallon (MPG) i byen
subset(Cars93, select = Model, subset = (MPG.city > 30))
# Find modelnavnet og prisintervallet for firecylindrede biler produceret i USA
subset(Cars93, select = c(Model, Min.Price, Max.Price), subset = (Cylinders == 4 & Origin == "USA"))
# Find producentens navn og modellens navn for alle biler, hvor miles per gallon (MPG) p� motorvejen er st�rre end medianen
subset(Cars93, select = c(Manufacturer, Model), subset = c(MPG.highway > median(MPG.highway)))
