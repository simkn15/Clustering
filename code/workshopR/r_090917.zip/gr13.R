# Bem�rk: Denne fil indeholder udelukkende beskrivelser af fremgangsm�der og producerer intet output!

# Hvis du �nsker at �ndre type, bredde eller farve p� en linje kan du tilf�je yderligere parametre:

# Brug lty-parameteret til at v�lge linjetype:
# lty = "solid" eller lty = 1 (standard)
# lty = "dashed" eller lty = 2
# lty = "dotted" eller lty = 3
# lty = "dotdash" eller lty = 4
# lty = "longdash" eller lty = 5
# lty = "twodash" eller lty = 6
# lty = "blank" eller lty = 0 (undertrykker tegning)

# Dette kald til plot-funktionen tegner eksempelvis en stiplet linje:
# plot(x, y, type = "l", lty = "dashed")

# Brug lwd-parameteret til at v�lge linjens bredde eller tykkelse (som standard har de tykkelse 1):
# plot(x, y, type = "l", lwd = 2)

# Brug col-parameteret til at v�lge linjens farve (som standard er de sorte):
# plot(x, y, type = "l", col = "red")

# Kaldet til plot-funktionen initialiserer grafikvinduet og tegner de f�rste linjer med bl�t
# plot(x, y1, type = "l", col = "blue")
# De efterf�lgende kald til lines-funktionen tegner yderligere linjer, f�rst med r�dt og s� med gult
# lines(x, y2, col = "red")
# lines(x, y3, col = "yellow")