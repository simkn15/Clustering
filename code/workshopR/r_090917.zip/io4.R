# Antag nu, at vi �nsker at indl�se data fra en kommasepareret fil (CSV-fil)

# CSV-filformatet er popul�rt, fordi mange programmer kan importere og eksportere data i dette format:
# R, Excel, andre regneark-programmer, mange databaseadministrationsv�rkt�jer og statistiske pakker

# Det er en fil med tabellariske data, hvor hver linje i filen indeholder en r�kke data med elementer separeret af komma
# Her er en meget simpel CSV-fil med tre r�kker og tre s�jler (f�rste linje er overskrifter, som ogs� er kommaseparerede)
# label,lbound,ubound
# low,0,0.674
# mid,0.674,1.64
# high,1.64,2.33

# Funktionen read.csv indl�ser data og laver en dataramme, som er den s�dvanlige R-repr�sentation for tabellariske data
# Denne funktion antager at din fil indeholder s�jleoverskrifter, medmindre vi fort�ller den andet
tbl <- read.csv("tabledata.csv")
tbl
# Bem�rk at read.csv tog s�jlenavnene fra den f�rste linje og brugte dem til datarammen
# Hvis ikke filen havde indeholdt overskrifter, s� ville vi skrive header = FALSE
tbl <- read.csv("tabledata2.csv", header = FALSE)
tbl
# Bem�rk at read.csv automatisk fortolker ikke-numeriske data som en faktor (kategorisk variabel)
# Lad os se p� strukturen af tbl
str(tbl)
# Nogle gange �nsker vi virkelig at data skal fortolkes som strenge, ikke faktorer
# I dette tilf�lde, s�t as.is-parameteret til TRUE
tbl <- read.csv("tabledata.csv", as.is = TRUE)
str(tbl)
