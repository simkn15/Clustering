# I R kaldes hver mulig v�rdi af en kategorisk variabel for et niveau og en vektor af niveauer kaldes en faktor

# Antag nu, at vi har en vektor med karakterstrenge eller heltal, som vi �nsker at R skal behandle som en faktor

# R-funktionen factor koder din vektor af diskrete v�rdier som en faktor:
# f <- factor(v)
# Hvis din vektor kun indeholder en delm�ngde af de mulige v�rdier, s� tilf�j et andet argument med de mulige niveauer
# f <- factor(v, levels)

# Konvertering af dine kategoriske data til en faktor kr�ver for det meste blot et kald til factor-funktionen
f <- factor(c("Sejr", "Sejr", "Nederlag", "Uafgjort", "Sejr", "Nederlag"))
f
# Bem�rk at factor-funktionen identificerer de forskellige niveauer i de kategoriske data og pakker dem i en faktor

# Hvis din vektor kun indeholder en delm�ngde af de mulige niveauer, s� vil R have et ufuldst�ndigt billede
# Antag at wday indeholder strengv�rdier, der giver ugedagen, hvor data blev observeret
wday <- c("Ons", "Tor", "Man", "Ons", "Tor", "Tor", "Tor", "Tir", "Tor", "Tir")
f <- factor(wday)
f
# R tror at mandag, onsdag, tirsdag og torsdag er de eneste mulige niveauer (fredag er ikke listet)
# Laboratoriepersonalet har tilsyneladende ingen observationer fra fredage, s� R ved ikke at det er en mulig v�rdi
# Derfor lister vi nu eksplicit de mulige niveauer for wday
f <- factor(wday, c("Man", "Tir", "Ons", "Tor", "Fre"))
f
# Nu forst�r R, at f er en faktor med fem forskellige niveauer - og den kender den korrekte r�kkef�lge

# Oprindeligt sorterede den dem alfabetisk efter ugedagenes navne p� dansk

# I mange situationer er det ikke n�dvendigt at kalde factor-funktionen eksplicit
# N�r en R-funktion skal bruge en faktor konverterer den ofte automatisk data til en faktor