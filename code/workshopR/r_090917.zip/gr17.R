# Antag nu, at vi �nsker et glattere t�thedsestimat end vi f�r ud af histogramkonstruktionen

# Vi kan bedre visualisere en underliggende fordeling, hvis vi tilf�jer en approksimeret t�thedsfunktion

# Vi genererer en stikpr�ve fra gammafordelingen
samp <- rgamma(500, 2, 2)
# Vi plotter histogrammet med sandsynlighedst�theder
hist(samp, 20, freq = FALSE, ylab = "T�thed", main = "Histogram med t�thedsestimat")
# Vi plotter den estimerede t�thedsfunktion
lines(density(samp))

# Funktionen density approksimerer formen af t�thedsfunktionen ikke-parametrisk
# Hvis vi kender den faktiske underliggende fordeling, s� kan vi med fordel plotte t�thedsfunktionen i stedet