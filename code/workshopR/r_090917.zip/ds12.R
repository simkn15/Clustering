# Antag nu, at en liste indeholder NULL-v�rdier, som vi �nsker at fjerne

# At finde og fjerne NULL-elementer kan v�re overraskende drilsk - her beskrives en fremgangsm�de:
# 1. R kalder sapply for at anvende funktionen is.null p� hvert element i listen
# 2. sapply returnerer en vektor af logiske v�rdier, som er sande, hvis det tilh�rende listeelement er NULL
# 3. R udv�lger v�rdier fra listen udfra denne vektor
# 4. R tildeler NULL til de valgte elementer, hvilket fjerner dem fra listen

# Nysgerrige deltagere vil m�ske undre sig over, hvordan en liste kan indeholde NULL-elementer, n�r elementer fjernes ved
# at s�tte dem til NULL, men det er dog muligt at oprette lister med NULL-elementer som det illustreres i dette eksempel:
mylist <- list("Hej", NULL, "dig")
mylist
# Her fjernes NULL-elementer fra mylist
mylist[sapply(mylist, is.null)] <- NULL
mylist
