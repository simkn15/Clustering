# Antag nu, at vi har en lille datam�ngde, som er for lille til at retf�rdigg�re at oprette en inputfil
# Vi vil gerne blot indtaste data direkte til vores arbejdsrum

# For meget sm� datas�t kan vi med fordel indtaste data ved hj�lp af c() konstrukt�ren til vektorer
scores <- c(61, 66, 90, 88, 100)
# Alternativ kan man lave en tom dataramme og bruge det indbyggede regnearklignende redigeringsv�rkt�j til at udfylde den
scores <- data.frame()
scores <- edit(scores)
