# Antag nu, at vi �nsker at generere alle kombinationer af n elementer, udtaget k ad gangen

# Vi kan bruge combn(1:5, 3) til at generere alle kombinationer af tallene 1 til 5, udtaget 3 ad gangen
combn(1:5, 3)
# Funktionen er ikke begr�nset til tal - vi kan ogs� generere kombinationer af strenge
# Her genereres alle kombinationer af 5 behandlinger, udtaget 3 ad gangen
combn(c("B1", "B2", "B3", "B4", "B5"), 3)
# Bem�rk: N�r antallet af elementer vokser kan antallet af kombinationer eksplodere, specielt hvis k ikke er t�t p� 1 eller n