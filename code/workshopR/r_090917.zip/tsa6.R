library(zoo)
library(tseries)

# Hent historiske finansielle data fra Yahoo Finance
ibm <- get.hist.quote(instrument = "ibm", quote = "Close", start = "1970-01-01", end = "1979-12-31")
# Forbrugerprisindeksdata (CPI-data) indl�ses
cpi <- read.zoo("CPIAUCNS.csv", header = TRUE, sep = ",", format = "%Y-%m-%d")
# S� vidt R ved, s� har vi kun en observation for den f�rste dag i hver m�ned og ingen observationer for de andre dage
# Dog ved vi, at hver CPI-v�rdi g�lder for de efterf�lgende dage i m�neden
# Vi laver et objekt af l�ngde nul med hver dag i �rtiet, men ingen data
dates <- seq(from = as.Date("1970-01-01"), to = as.Date("1979-12-31"), by = 1)
empty <- zoo(, dates)
# S� tager vi foreningsm�ngden af CPI-data og objektet af l�ngde nul, hvilket giver et datas�t fyldt med NA-v�rdier
filled.cpi <- merge(cpi, empty, all = TRUE)
filled.cpi
# Den resulterende tidsr�kke indeholder hver kalenderdag med NA'er, hvor der ikke var en observation
# Et mere almindeligt behov er, at erstatte hver NA med den nyeste observation fra og med denne dato
# Funktionen na.locf fra zoo-pakken g�r pr�cist dette!
filled.cpi <- na.locf(merge(cpi, empty, all = TRUE))
filled.cpi
# Januars v�rdi (37,8) videref�res indtil 1. februar, hvor den erstattes af februars v�rdi (38,0)
# Hver dag har den nyeste CPI-v�rdi fra og med denne dato, hvilket kan bruges til at l�se problemet fra forrige fil
# Husk: Den daglige pris p� IBM-aktien og de m�nedlige CPI-data havde ingen f�llesm�ngde p� visse dage!
# En l�sning er, at udvide IBM-data til at inkludere CPI-datoerne og tage f�llesm�ngden (giver m�nedlige observationer)
filled.ibm <- na.locf(merge(ibm, zoo(, index(cpi))))
merge(filled.ibm, cpi, all = FALSE)
# En anden l�sning er, at udfylde CPI-data og s� tage f�llesm�ngden med IBM-data (giver daglige observationer)
merge(ibm, filled.cpi, all = FALSE)
