# Bem�rk: Denne fil indeholder udelukkende beskrivelser af fremgangsm�der og producerer intet output!

# Antag nu, at vi �nsker at fjerne elementer fra en liste ud fra en betingelse
# M�ske vi �nsker at fjerne elementer, som er st�rre end eller mindre end en bestemt v�rdi?

# Husk:
# 1. En liste kan indekseres af en logisk vektor - n�r vektorelementet er TRUE, s� v�lges det tilh�rende listeelement
# 2. Vi kan fjerne listeelementer ved at tildele v�rdien NULL til dem

# Her fjernes elementer fra en liste, mylist, hvis elementernes v�rdier er 0:
# mylist[mylist == 0] <- NULL
# Bem�rk at vi konstruerede en logisk vektor, som identificerede de u�nskede v�rdier (mylist == 0)
# S� udvalgte vi hereffter disse elementer fra listen og tildelte NULL til dem

# Dette udtryk vil fjerne NA-v�rdier fra listen:
# mylist[is.na(mylist)] <- NULL

# S� langt, s� godt - problemerne opst�r, n�r ikke vi let kan opbygge den logiske vektor!
# Dette sker ofte, n�r man bruger en funktion, der ikke kan h�ndtere en liste (eksempelvis abs-funktionen)
# Antag at vi �nsker at fjerne listeelementer, hvis absolutte v�rdier er mindre end 1
# mylist[abs(mylist) < 1] <- NULL vil give f�lgende fejl: Error in abs(mylist) : non-numeric argument to function
# Den simpleste l�sning er, at udflade listen til en vektor ved at kalde unlist og s� teste p� vektoren:
# mylist[abs(unlist(mylist)) < 1] <- NULL
# En mere elegant l�sning ville v�re at bruge lapply-funktionen til at anvende abs p� hvert element i listen:
# mylist[lapply(mylist, abs) < 1] <- NULL

# OPGAVE: Afpr�v dette p� en liste kaldet mylist indeholdende tallet 0, en NA-v�rdi og forskellige positive og negative tal

# Lister kan ogs� indeholde komplekse objekter, ikke blot atomare v�rdier
# Antag at mymodels er en liste af line�re modeller, som er lavet med lm-funktionen
# Dette udtryk vil fjerne enhver model, hvis R^2-v�rdi er mindre end 0,30:
# mymodels[sapply(mymodels, function(m) summary(m)$r.squared < 0.3)] <- NULL
