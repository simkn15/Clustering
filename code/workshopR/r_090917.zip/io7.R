# Antag nu, at vi �nsker at v�lge en fil interaktivt
myData <- file.choose()
# Eller at vi �nsker at indl�se tabellariske data fra udklipsholderen
myData <- read.table("clipboard", header = TRUE)
