# Antag nu, at vi �nsker at tilf�je en eller flere nye r�kker til en dataramme

# Datas�ttet suburbs indl�ses
suburbs <- read.csv("suburbs.csv")
suburbs
# Vi laver en ny dataramme med �n r�kke med nye data
newRow <- data.frame(city = "West Dundee", county = "Kane", state = "IL", pop = 5428)
# Herefter kan rbind-funktionen bruges til at tilf�je denne dataramme med �n r�kke til vores eksisterende dataramme
suburbs <- rbind(suburbs, newRow)
# Havde vi i stedet �nsket at tilf�je en ny s�jle, s� kunne vi have brugt cbind
# Bem�rk: Det er vigtigt at den nye r�kke bruger samme s�jlenavne som den eksisterende dataramme!

# Det havde ogs� v�ret muligt at tilf�je flere r�kker, da rbind tillader flere argumenter
suburbs <- rbind(suburbs,
                 data.frame(city = "West Dundee", county = "Kane", state = "IL", pop = 5428),
                 data.frame(city = "East Dundee", county = "Kane", state = "IL", pop = 2955))