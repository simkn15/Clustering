# Antag nu, at vi �nsker at tildele beskrivende navne til r�kkerne eller s�jlerne i en matrix

# Betragt denne matrix af korrelationer mellem priserne for IBM-, Microsoft- og Google-aktien
tech.corr <- matrix(c(1.000, 0.556, 0.390, 0.556, 1.000, 0.444, 0.390, 0.444, 1.000), 3, 3)
tech.corr
# Vi tilf�jer r�kke- og s�jlenavne, som �ger l�sbarheden af outputtet
rownames(tech.corr) <- c("IBM", "MSFT", "GOOG")
colnames(tech.corr) <- c("IBM", "MSFT", "GOOG")
tech.corr
# Nu ved l�seren hvilke r�kker og s�jler, der h�rer til hvilke aktier

# En anden fordel er, at vi nu kan referere til matrixelementer med disse navne
# Hvad er korrelationen mellem IBM og GOOG?
tech.corr["IBM", "GOOG"]
