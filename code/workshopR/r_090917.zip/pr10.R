# Antag nu, at vi givet en sandsnlighed p og en fordeling �nsker at bestemme den tilh�rende kvartil for p:
# Dvs. v�rdien x, s�dan at P(X <= x) = p

# Hver indbygget fordeling indeholder en kvartilfunktion, som konverterer sandsynligheder til kvartiler
# Funktionens navn er "q" efterfulgt af fordelingens navn (f.eks. er qnorm kvartilfunktionen for normalfordelingen)
# Kvartilfunktionens f�rste argument er sandsynligheden og de resterende argumenter er fordelingens parametre
qnorm(0.05, mean = 100, sd = 15)
# Et almindeligt eksempel p� beregning af kvartiler er, n�r vi beregner gr�nserne for et konfidensinterval
# Hvis vi gerne vil have 95% konfidensintervallet (alpha = 0,05) for en standardnormal variabel skal vi bruge
# kvartilerne med sandsynlighederne for alpha / 2 = 0,025 og (1 - alpha) / 2 = 0,975, som beregnes med qnorm:
qnorm(0.025)
qnorm(0.975)
# Det f�rste argument kan imidlertid ogs� v�re en vektor af sandsynligheder (s� returneres en vektor af kvartiler)
qnorm(c(0.025, 0.975))

# Udforsk ogs� funktioner som qbinom, qgeom, qpois, qt, qexp, qgamma og qchisq