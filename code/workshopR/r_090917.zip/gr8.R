library(MASS)

# S�kaldte "conditioning plots" er en anden m�de at unders�ge og illustrere effekten af en faktor p� data

# Datas�ttet Cars93 indeholder 27 variable, som beskriver 93 bilmodeller fra og med 1993:
# To numeriske variable er MPG.city (miles per gallon i byen) og Horsepower (motorens hestekr�fter)
# En kategorisk variabel er Origin (oprindelse), som kan v�re USA eller non-USA, alt efter hvor modellen blev bygget

# Er der forskellige sammenh�nge for USA-modeller og ikke-USA-modeller?
coplot(Horsepower ~ MPG.city | Origin, data = Cars93, xlab = "Miles per gallon i byen", ylab = "Hestekr�fter")

# Hvis virkelig vi beh�ver et monster med 300 hestekr�fter, s� er vi n�dt til at k�be en bil, der er bygget i USA
# Hvis vi �nsker h�jt antal miles per gallon i byen har vi flere valgmuligheder blandt ikke-USA-modeller