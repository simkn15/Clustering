# Antag nu, at vi �nsker at generere en tilf�ldig permutation af en vektor

# Ofte forbindes sample-funktionen med udv�lgelse fra store datas�t
# Standardparametrene giver dig mulighed for at lave en tilf�ldig omarrangering af datas�ttet:
# "V�lg alle elementerne fra v i en tilf�ldig r�kkef�lge og brug hvert element pr�cis �n gang"

# Vi laver en tilf�ldig permutation af 1, 2, ..., 10:
sample(1:10)