library(faraway)

# Antag nu, at vi plotter par af datapunkter og gerne vil tilf�je en linje, der illustrerer deres line�re regression

# Vi modellerer strongx-datas�ttet fra faraway-pakken
data(strongx)
# Lav et modelobjekt
model <- lm(crossx ~ energy, data = strongx)
# Plot (x, y)-parrene
plot(crossx ~ energy, data = strongx, xlab = "Energi", ylab = "Tv�rsnit")
# Alternativ syntaks
plot(strongx$energy, strongx$crossx, xlab = "Energi", ylab = "Tv�rsnit")
# Brug abline-funktionen til at indtegne den tilpassede regressionslinje
abline(model)