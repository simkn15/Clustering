# Antag nu, at vi har parrede observationer: (x_1, y_1), (x_2, y_2), ..., (x_n, y_n)
# Hvis data lagres i to parallelle vektorer, x og y, s� kan disse bruges som argumenter i plot-funktionen:
# plot(x, y)
# Hvis data lagres i en dataramme med to s�jler, dfrm, s� kan datarammen plottes:
# plot(dfrm)

# Det indbyggede datas�t cars indeholder to s�jler, speed (afbildes p� x-aksen) og dist (afbildes p� y-aksen)

# Fremstil et scatterplot
plot(cars)
# Funktionens form�l er, at fremstille et plot af (x, y)-parrene i grafikvinduet, s� den returnerer ikke noget

# For datarammer indeholdende mere end to s�jler fremstilles flere scatterplot

# For at f� et scatterplot skal data v�re numeriske (bem�rk: plot er en polymorf funktion!)