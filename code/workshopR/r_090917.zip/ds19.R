# Antag nu, at vores data er organiseret efter r�kker og vi �nsker at samle det i en dataramme

# Data kommer ofte som en samling observationer - hvor vi f�r r�kker �n ad gangen, frem for s�jler �n ad gangen

# Hver observation er en tupel, der indeholder flere v�rdier - �n for hver observeret variabel
# I det f�lgende lagres hver tupel som en dataramme med �n r�kke (hvis man kun har numeriske data kan vektorer bruges)
obs <- list()
obs[[1]] <- data.frame(pred1 = -2.7528917, pred2 = -1.40784130, pred3 = "AM", resp = 12.57715)
obs[[2]] <- data.frame(pred1 = -0.3626909, pred2 = 0.31286963, pred3 = "AM", resp = 21.02418)
obs[[3]] <- data.frame(pred1 = -1.0416039, pred2 = -0.69685664, pred3 = "PM", resp = 18.94694)
obs[[4]] <- data.frame(pred1 = 1.2666820, pred2 = -1.27511434, pred3 = "PM", resp = 18.98153)
obs[[5]] <- data.frame(pred1 = 0.7806372, pred2 = -0.27292745, pred3 = "AM", resp = 19.59455)
obs[[6]] <- data.frame(pred1 = -1.0832624, pred2 = 0.73383339, pred3 = "AM", resp = 20.71605)
obs[[7]] <- data.frame(pred1 = -2.0883305, pred2 = 0.96816822, pred3 = "PM", resp = 22.70062)
obs[[8]] <- data.frame(pred1 = -0.7063653, pred2 = -0.84476203, pred3 = "PM", resp = 18.40691)
obs[[9]] <- data.frame(pred1 = -0.8394022, pred2 = 0.31530793, pred3 = "PM", resp = 21.00930)
obs[[10]] <- data.frame(pred1 = -0.4966884, pred2 = -0.08030948, pred3 = "AM", resp = 19.31253)

# Vi binder disse r�kker sammen til en dataramme, hvilket er hvad rbind-funktionen g�r

# Her bindes de to f�rste observationer sammen
rbind(obs[[1]], obs[[2]])
# Vi vil gerne binde alle observationer sammen, ikke blot de f�rste to - s� vi bruger do.call-funktionen
do.call(rbind, obs)

# Hvis obs er en liste af lister frem for en liste af datarammer med �n r�kke:
# Vi kan transformere r�kkerne til datarammer ved brug af Map-funktionen og s� bruge ovenst�ende fremgangsm�de:
# dfrm <- do.call(rbind, Map(as.data.frame, obs))
