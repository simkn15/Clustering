# x er en vektor af diskrete v�rdier, i dette eksempel genereret fra Poissonfordelingen
x <- rpois(100, 5)
# Vi kunne godt bruge hist-funktionen til at fremstille et histogram af diskrete data
# Funktionen er imidlertid mere rettet mod kontinuerte data, s� vi bruger i stedet plot-funktionen med type = "h"
plot(table(x), type = "h", lwd = 5, ylab = "Frekvens")
# Bem�rk at lwd = 5 g�r s�jlerne lidt bredere

# Hvis vi foretr�kker et histogram med relative hyppigheder, s� kan hvert table-element skaleres med l�ngden af x
plot(table(x) / length(x), type = "h", lwd = 5, ylab = "Frekvens")