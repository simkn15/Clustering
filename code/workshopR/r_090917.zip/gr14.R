# Funktionen abline kan bruges til at tegne en vertikal eller horisontal linje:
# abline(v = x) tegner en vertikal linje ved x
# abline(h = y) tegner en horisontal linje ved y

# Antag nu, at vi har en vektor med en stikpr�ve best�ende af 100 uafh�ngige tal fra den uniforme fordeling p� (0, 1)
samp <- runif(100, 0, 1)
# Vi plotter stikpr�vens punkter
plot(samp, ylim = c(-0.2, 1.2))
# Vi beregner stikpr�vens middelv�rdi
m <- mean(samp)
# Vi indtegner en linje gennem middelv�rdien
abline(h = m)
# Vi vil gerne illustrere stikpr�vens standardafvigelse grafisk - s� vi beregner den og indtegner prikkede
# linjer ved plus-minus 1 standardafvigelse og plus-minus 2 standardafvigelser fra stikpr�vens middelv�rdi
stdevs <- m + c(-2, -1, +1, +2) * sd(samp)
abline(h = stdevs, lty = "dotted")