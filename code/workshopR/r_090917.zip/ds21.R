# Antag nu, at vi �nsker at udv�lge s�jler fra en dataramme efter deres position

# For at udv�lge en enkelt s�jle, brug denne listeoperator:
# dfrm[[n]]
# Denne returnerer �n s�jle - mere specifikt den n'te s�jle af datarammen dfrm

# For at udv�lge en eller flere s�jler og pakke dem ind i en dataramme, brug disse udtryk:
# dfrm[n] - returnerer en dataramme best�ende af kun den n'te s�jle af dfrm
# dfrm[c(n_1, n_2, ..., n_k)] - returnerer en dataramme opbygget af s�jlerne p� positionerne n_1, n_2, ..., n_k i dfrm
# Man kan ogs� bruge matrixlignende indeksering til at udv�lge en eller flere s�jler:
# dfrm[, n]
# dfrm[, c(n_1, n_2, ..., n_k)]

# Datas�ttet suburbs indl�ses
suburbs <- read.csv("suburbs.csv")
suburbs
# Brug simpel listenotation til at udv�lge pr�cis �n s�jle, eksempelvis den f�rste
suburbs[[1]]
# F�rste s�jle pakket ind i en dataramme
suburbs[1]
# F�rste og tredje s�jle pakket ind i en dataramme
suburbs[c(1, 3)]

# Som n�vnt kan matrixnotationen ogs� bruges til at udv�lge s�jler, men pas p�:
# Nogle gange f�r du en s�jle, andre gange en dataramme - alt efter hvor mange indekser du bruger!

# Her returneres en s�jle
suburbs[, 1]
# Her returneres en dataramme ved brug af samme matrixlignende syntaks med flere indekser
suburbs[, c(1, 4)]
# Hvis vi ogs� i f�rstn�vnte tilf�lde �nsker en dataramme frem for en s�jle kan vi tilf�je drop = FALSE
suburbs[, 1, drop = FALSE]

# Brug eventuelt i stedet listeoperatorerne beskrevet ovenfor
