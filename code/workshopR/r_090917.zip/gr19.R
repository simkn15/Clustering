library(MASS)

# Cars93-datas�ttet indeholder en priss�jle og vi vil unders�ge om den er normalfordelt ved at fremstille et QQ-plot
qqnorm(Cars93$Price, main="QQ-plot: Price")
# En diagonal linje tilf�jes til QQ-plottet
qqline(Cars93$Price)
# Hvis data havde en perfekt normalfordeling, s� ville punkterne ligge pr�cist p� den diagonale linje
# Mange punkter er t�t p� linjen, specielt i den midterste del, men punkterne i halerne er temmelig langt v�k!

# For mange punkter over linjen indikerer en generel venstresk�vhed, hvorfor vi laver en logaritmisk transformation
qqnorm(log(Cars93$Price), main="QQ-plot: log(Price)")
qqline(log(Cars93$Price))
# Det ser ud som om, at log(Price) er approksimativt normalfordelt