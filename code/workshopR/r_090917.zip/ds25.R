# Antag nu, at vores dataramme indeholder NA-v�rdier, hvilket skaber et problem for os

# Her har vi en dataramme med NA-v�rdier
x <- c(-0.9714511, NA, 0.3367627, 1.7520504, 0.4918786)
y <- c(-0.4578746, 3.1663282, NA, 0.7406335, 1.4543427)
dfrm <- data.frame(x, y)
dfrm
# Her vil cumsum fejle, fordi inputtet indeholder NA-v�rdier
cumsum(dfrm)
# En l�sning er, at fjerne alle r�kker, der indeholder NA-v�rdier - det er hvad funktionen na.omit g�r
na.omit(dfrm)
# S� kan cumsum forts�tte summeringen
cumsum(na.omit(dfrm))
# Dette virker ogs� for vektorer og matricer, men ikke for lister

# Pas p�: Hvis man smider for mange observationer v�k, s� kan det resultere i meningsl�se resultater
# na.omit vli fjerne hele r�kker, ikke bare NA-v�rdierne, hvilket kan eliminere meget brugbar information
