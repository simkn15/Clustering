library(zoo)

# Vi vender nu tilbage til et tidligere eksempel

# Priser
prices <- c(132.45, 130.85, 130.00, 129.55, 130.85)
# Datoer
dates <- as.Date(c("2010-01-04", "2010-01-05", "2010-01-06", "2010-01-07", "2010-01-08"))
# Lav et zoo-objekt, som indeholder prisen for IBM-aktien for de f�rste fem dage af 2010
ibm.daily <- zoo(prices, dates)
ibm.daily
# Den i'te observation fra tidsr�kken ibm.daily udv�lges som ibm.daily[i]
ibm.daily[1]
ibm.daily[2]
# Vi kan ogs� udv�lge en observation efter dato (vores indeks er opbygget af Date-objekter)
ibm.daily[as.Date("2010-01-05")]
# Eller vi kan udv�lge observationer efter en vektor af Date-objekter
dates <- seq(as.Date("2010-01-04"), as.Date("2010-01-08"), by = 2)
ibm.daily[dates]
# Funktionen window er lettere at bruge til udv�lgelsen, hvis datoerne er fortl�bende
window(ibm.daily, start = as.Date("2010-01-05"), end = as.Date("2010-01-07"))