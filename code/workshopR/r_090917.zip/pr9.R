# Antag nu, at vi �nsker at beregne fordelingsfunktionen for en kontinuert stokastisk variabel

# Brug fordelingsfunktionen, som beregner P(X <= x):
# For alle indbyggede sandsynlighedsfordelinger findes en fordelingsfunktion, hvis navn er "p" efterfulgt af fordelingens navn

# Den signifikante forskel fra forrige fil er, at kontinuerte variable ikke har en "sandsynlighed" i et enkelt punkt, P(X = x)
# I stedet har de en t�thed i et punkt!

# Det antages at m�nds h�jder er normalfordelte med en middelv�rdi p� 70 tommer og en standardafvigelse p� 3 tommer
# Vi kan bruge pnorm til at beregne sandsynligheden for, at en mand er lavere end 66 tommer under denne antagelse
# Udtrykt mere matematisk vil vi gerne beregne P(X <= 66) givet at X ~ N(70, 3)
pnorm(66, mean = 70, sd = 3)
# Tilsvarende kan vi beregne sandsynligheden for, at en eksponentialfordelt variabel med middelv�rdi 40 kan v�re mindre end 20
pexp(20, rate = 1/40)
# Ligesom for diskrete sandsynligheder kan vi f� overlevelsesfunktionen, P(X > x), ved at skrive lower.tail = FALSE
# Her beregnes sandsynligheden for, at den f�romtalte eksponentialfordelte variabel kan v�re st�rre end 50
pexp(50, rate = 1/40, lower.tail = FALSE)
# Intervalsandsynligheden for en kontinuert stokastisk variabel beregnes som differencen mellem to kumulative sandsynligheder:
# P(x_1 < X < x_2) = P(X < x_2) - P(X < x_1)
# For den samme eksponentialfordelte variabel beregnes sandsynligheden for, at den kan falde mellem 20 og 50, P(20 < X < 50)
pexp(50, rate = 1/40) - pexp(20, rate = 1/40)
