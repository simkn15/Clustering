# Det indbyggede pressure-datas�t plottes som et scatterplot
plot(pressure, xlab = "Temperatur (grader Celsius)", ylab = "Tryk (mmHg)", main = "Trykdata: Kviks�lvs damptryk")
# Vi kan i stedet tegne en linje
plot(pressure, xlab = "Temperatur (grader Celsius)", ylab = "Tryk (mmHg)", main = "Trykdata: Kviks�lvs damptryk", type = "l")
