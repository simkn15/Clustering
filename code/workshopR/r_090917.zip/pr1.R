# Antag nu, at vi gerne vil beregne antallet af kombinationer af n elementer, udtaget k ad gangen

# Et almindeligt problem, n�r man skal beregne sandsynligheder for diskrete variable, er at t�lle antallet af kombinationer:
# Antallet af forskellige delm�ngder af st�rrelse k, som kan dannes ud fra en m�ngde med n elementer
# Tallet er givet ved n! / r!(n - r)!, men det er meget mere bekvemt at bruge choose-funktionen (specielt for store n og k)

# Find antallet af m�der, hvorp� 3 elementer kan udtages af en m�ngde med 5 elementer
choose(5, 3)
# Find antallet af m�der, hvorp� 3 elementer kan udtages af en m�ngde med 50 elementer
choose(50, 3)
# Find antallet af m�der, hvorp� 30 elementer kan udtages af en m�ngde med 50 elementer
choose(50, 30)

# Disse tal er ogs� kendt som binomialkoefficienter