# Antag nu, at vi �nsker at udv�lge en enkelt r�kke eller s�jle fra en matrix

# Vi initialiserer nu en matrix med 3 r�kker og 4 s�jler
mat <- matrix(1:12, 3, 4)
mat
# Normalt, n�r man udv�lger en r�kke eller s�jle fra en matrix, s� resulterer det i en dimensionsl�s vektor
# Her benyttes normal indeksering til at udv�lge matricens f�rste r�kke
mat[1, ]
# Her benyttes normal indeksering til at udv�lge matricens tredje s�jle
mat[, 3]
# N�r man tilf�jer argumentet drop = FALSE bevarer R derimod dimensionerne - s� hvis en r�kke udv�lges f�s en 1 � n-matrix
mat[1, , drop = FALSE]
# Tilsvarende, n�r man v�lger en s�jle med drop = FALSE, f�s en n � 1-matrix
mat[, 3, drop = FALSE]
