# Med et stort antal variable kan det v�re sv�rt at finde sammenh�nge mellem dem!
# Det kan v�re brugbart at kigge p� scatterplot af alle par af variable

# Datas�ttet iris indeholder fire numeriske variable og en kategorisk variabel
head(iris)
# Ved at plotte fire s�jler fremstilles flere scatterplot
plot(iris[,1:4])