# Beskrivelse af fremgangsm�de:
# Vi bruger ppoints-funktionen til at generere en r�kke af punkter mellem 0 og 1
# Vi transformerer disse punkter til kvartiler ved brug af quantile-funktionen for den antagede fordeling
# Vi sorterer vores stikpr�vedata.
# Vi plotter de sorterede data mod de beregnede kvartiler
# Vi bruger abline til at plotte den diagonale linje

# Rateparameter
lambda <- 1/10
# Vi genererer en tilf�ldig stikpr�ve fra eksponentialfordelingen med middelv�rdi 10 (eller �kvivalent rate 1/10)
y <- rexp(1000, rate = lambda)
# Vi plotter de sorterede data mod de beregnede kvartiler som beskrevet i fremgangsm�den ovenfor
plot(qexp(ppoints(y), rate = lambda), sort(y), main = "QQ-plot", xlab = "Theoretical Quantiles", ylab = "Sample Quantiles")
# Kvartilfunktionen for eksponentialfordelingen er qexp, som tager et rateargument

# Vi tilf�jer den diagonale linje
abline(a = 0, b = 1)